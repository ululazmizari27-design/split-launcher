package com.splitlauncher.app

import android.app.ActivityOptions
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

data class AppItem(val label: String, val pkg: String?) {
    override fun toString() = label
}

/** Posisi panel dalam pecahan layar (0..1): kiri, atas, kanan, bawah */
data class Slot(val l: Float, val t: Float, val r: Float, val b: Float)

class MainActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val appSpinners = mutableListOf<Spinner>()
    private lateinit var layoutSpinner: Spinner

    private val layouts = linkedMapOf(
        "2x2 (4 aplikasi)" to listOf(
            Slot(0f, 0f, .5f, .5f), Slot(.5f, 0f, 1f, .5f),
            Slot(0f, .5f, .5f, 1f), Slot(.5f, .5f, 1f, 1f)
        ),
        "1 besar + 2 kecil (3 aplikasi)" to listOf(
            Slot(0f, 0f, .5f, 1f), Slot(.5f, 0f, 1f, .5f), Slot(.5f, .5f, 1f, 1f)
        ),
        "2 kiri-kanan (2 aplikasi)" to listOf(
            Slot(0f, 0f, .5f, 1f), Slot(.5f, 0f, 1f, 1f)
        ),
        "4 baris (4 aplikasi)" to listOf(
            Slot(0f, 0f, 1f, .25f), Slot(0f, .25f, 1f, .5f),
            Slot(0f, .5f, 1f, .75f), Slot(0f, .75f, 1f, 1f)
        )
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val apps = listOf(AppItem("(kosong)", null)) + loadApps()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(24))
        }

        col.addView(TextView(this).apply {
            text = "Split Launcher (prototipe)"
            textSize = 20f
        })

        col.addView(label("Layout"))
        layoutSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_item, layouts.keys.toList()
            ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        }
        col.addView(layoutSpinner)

        for (i in 1..4) {
            col.addView(label("Aplikasi $i"))
            val sp = Spinner(this).apply {
                adapter = ArrayAdapter(
                    this@MainActivity, android.R.layout.simple_spinner_item, apps
                ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            }
            appSpinners.add(sp)
            col.addView(sp)
        }

        col.addView(Button(this).apply {
            text = "Luncurkan"
            setOnClickListener { launchAll() }
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(20) })

        col.addView(Button(this).apply {
            text = "Buka Opsi Pengembang"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
                } catch (e: Exception) {
                    toast("Aktifkan dulu Opsi Pengembang di Pengaturan > Tentang ponsel")
                }
            }
        })

        col.addView(TextView(this).apply {
            textSize = 12f
            setPadding(0, dp(16), 0, 0)
            text = "Agar jendela bisa diposisikan, aktifkan di Opsi Pengembang:\n" +
                "- Enable freeform windows\n" +
                "- Force activities to be resizable\n" +
                "Lalu restart HP. Tutup dulu aplikasi yang mau dipakai sebelum meluncurkan. " +
                "Aplikasi ke-2 dan seterusnya dibuka berurutan dengan jeda setengah detik."
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 13f
        setPadding(0, dp(12), 0, 0)
    }

    private fun loadApps(): List<AppItem> {
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(main, 0)
            .map { AppItem(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun launchAll() {
        val slots = layouts[layoutSpinner.selectedItem as String] ?: return
        val dm = resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels

        var delay = 0L
        var count = 0
        slots.forEachIndexed { i, s ->
            val pkg = (appSpinners[i].selectedItem as AppItem).pkg ?: return@forEachIndexed
            val rect = Rect((s.l * w).toInt(), (s.t * h).toInt(), (s.r * w).toInt(), (s.b * h).toInt())
            handler.postDelayed({ open(pkg, rect) }, delay)
            delay += 500
            count++
        }
        if (count == 0) toast("Pilih minimal satu aplikasi")
    }

    private fun open(pkg: String, rect: Rect) {
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val options = ActivityOptions.makeBasic().setLaunchBounds(rect)
        try {
            startActivity(intent, options.toBundle())
        } catch (e: Exception) {
            toast("Gagal membuka $pkg: ${e.message}")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
